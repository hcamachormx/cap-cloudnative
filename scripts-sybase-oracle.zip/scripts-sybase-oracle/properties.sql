exec sp_helpsort
go
select @@version
go