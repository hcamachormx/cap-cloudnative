# ** SET THE VALUE FOR THE OFFLINE_CAPTURE_COLUMN_DELIMITER
# ** echoed through bcp to COLUMN.TXT
#export OFFLINE_CAPTURE_COLUMN_DELIMITER=<EOC>
# ** SET THE VALUE FOR THE OFFLINE_CAPTURE_ROW_DELIMITER
# ** echoed through bcp to ROW.TXT
#
#export OFFLINE_CAPTURE_ROW_DELIMITER=<EOR>
# ** SET THE SCRIPT VERSION ENVIRONMENT VARIABLE
export OMWB_SCRIPT_VERSION=15
# ** SET THE VALUE FOR THE OMWB FILE ENVIRONMENT VARIABLE
export OMWB_SCRIPT_FILE=$3/$3_INFO.TXT

# *** CHECK THAT THREE PARAMETERS HAVE BEEN ENTERED
# *** THE PASSWORD CAN BE "", SO WE DON't DO THE SAME CHECK FOR THAT

if [ $# -lt 4 ]; then
	echo "Se requieren 4 argumentos"
 	exit 1
fi
void_flag=0
if [ -z $1 ]; then
   void_flag=1
   echo "1" $1
fi
if [ -z $3 ]; then
   void_flag=1
   echo "3" $3
fi
if [ -z $4 ]; then
   void_flag=1
   echo "4" $4
fi
if [ $void_flag -gt 0 ]; then
	echo "---- ** Error executing the script"
	echo "----"
	echo "---- To run this script, enter the following command at the prompt ----"
	echo "----"
	echo "---- OMWB_OFFLINE_CAPTURE login_id password database_name server_name"
	echo "---- where,"
	echo "---- login_id is a login id which has been granted db_datareader"
	echo "---- and view definition on database_name"
	echo "---- password is the password for the login id"
	echo "---- database_name is the name of the database you wish to capture"
	echo "---- server_name is the name of the server on which the database resides"
	echo "---- For example,"
	echo "----      OMWB_OFFLINE_CAPTURE sa sapwd employeeDB DEPT1_SERVER"
	echo "----"
	echo "-----------------------------------------------------------------------"
	exit 1
fi
# ** DISPLAY THE HELP PAGE IF THE USER REQUESTS IT
help_flag=false
if [ $1 = '-h' ]; then
  help_flag=true
fi
if [ $1 = 'help' ]; then
  help_flag=true
fi
if [ $1 = '?' ]; then
  help_flag=true
fi
if [ $1 = '-?' ]; then
  help_flag=true
fi
if [ $help_flag = true ]; then
	echo "-----------------------------------------------------------------------"
	echo "---------------------  Oracle Migration Workbench ---------------------"
	echo "---------------------         Release $OMWB_SCRIPT_VERSION       ---------------------"
	echo "-----------------------------------------------------------------------"
	echo "---- This script will generate delimited flat files containing     ----"
	echo "---- schema metadata from the database you wish to migrate. This   ----"
	echo "---- script will envoke the Bulk Copy Program -BCP- that should be ----"
	echo "---- part of your Sybase install base.                         ----"
	echo "---- Please ensure that your path points to the version of BCP     ----"
	echo "---- that is installed with the Sybase from which you wish     ----"
	echo "---- to migrate. Your current path setting is listed below:        ----"
	echo "----"
	pwd
	echo "----"
	echo "----"
	echo "---- To run this script, enter the following command at the prompt ----"
	echo "----"
	echo "---- OMWB_OFFLINE_CAPTURE login_id password database_name server_name"
	echo "---- where,"
	echo "---- dba_login_id is a login id which has been granted db_datareader"
	echo "---- and view definition on database_name"
	echo "---- password is the password for the login id"
	echo "---- database_name is the name of the database you wish to capture"
	echo "---- server_name is the name of the server on which the database resides"
	echo "---- For example,"
	echo "----      OMWB_OFFLINE_CAPTURE sa sapwd employeeDB DEPT1_SERVER"
	echo "----"
	echo "-----------------------------------------------------------------------"
	exit 1
fi
# *** DISPLAY THE SCRIPT VERSION IF THE USER REQUESTS IT
version_flag=0

if [ $1 = 'ver' ]; then
version_flag=1
fi
if [ $1 = 'version' ]; then
version_flag=1
fi
if [ $version_flag -gt 0 ]; then
	echo "-----------------------------------------------------------------------"
	echo "---- This is the Oracle Migration Workbench offline capture script"
	echo "---- version $OMWB_SCRIPT_VERSION for Sybase "
	echo "-----------------------------------------------------------------------"
	exit 1
fi

# *** START THE EXECUTION OF THE SCRIPT INSTRUCTIONS
# ** CREATE THE OUTPUT DIRECTORIES
mkdir master
mkdir $3
# *** CALL THE BCP SCRIPT TO CREATE THE METADATA FILES
./SYB15_BCP_SCRIPT.sh $1 $2 $3 $4 $OFFLINE_CAPTURE_COLUMN_DELIMITER $OFFLINE_CAPTURE_ROW_DELIMITER
# *** CHECK THAT ALL DATABASE META FILES HAVE BEEN CREATED
if ! [ -f $3/SYB12_SYSUSERS.dat ]; then
        echo "** ERROR $3\SYB12_SYSUSERS.dat has not been created. Please check the screen output and .err files to detect the problem. Execute the script again when the problem is fixed or contact your Oracle representative if the problem persists."
fi
if ! [ -f $3/SYB12_SYSOBJECTS.dat ]; then
        echo "** ERROR $3\SYB12_SYSOBJECTS.dat has not been created. Please check the screen output and .err files to detect the problem. Execute the script again when the problem is fixed or contact your Oracle representative if the problem persists."
fi
if ! [ -f $3/SYB12_SYSTYPES.dat ]; then
        echo "** ERROR $3\SYB12_SYSTYPES.dat has not been created. Please check the screen output and .err files to detect the problem. Execute the script again when the problem is fixed or contact your Oracle representative if the problem persists."
fi
if ! [ -f $3/SYB12_SYSCOLUMNS.dat ]; then
        echo "** ERROR $3\SYB12_SYSCOLUMNS.dat has not been created. Please check the screen output and .err files to detect the problem. Execute the script again when the problem is fixed or contact your Oracle representative if the problem persists."
fi
if ! [ -f $3/SYB12_SYSCOMMENTS.dat ]; then
        echo "** ERROR $3\SYB12_SYSCOMMENTS.dat has not been created. Please check the screen output and .err files to detect the problem. Execute the script again when the problem is fixed or contact your Oracle representative if the problem persists."
fi
if ! [ -f master/SYB12_SYSDATABASES.dat ]; then
		echo "** ERROR master\SYB12_SYSDATABASES.dat has not been created. Please check the screen output and .err files to detect the problem. Execute the script again when the problem is fixed or contact your Oracle representative if the problem persists."
fi
# ** UPDATE THE OMWB FILE - THIS HOLDS SCRIPT AND PERTINENT SOURCE DATABASE SERVER INFO
echo OMWB REPORT FOR $3                            >  $OMWB_SCRIPT_FILE
echo "____________________________________________"  >> $OMWB_SCRIPT_FILE
echo "* SCRIPT EXECUTION DATE AND TIME:          "   >> $OMWB_SCRIPT_FILE
date                                               >> $OMWB_SCRIPT_FILE
echo "-                                    "         >> $OMWB_SCRIPT_FILE
echo "SYSTEM PROPERTIES                    "         >> $OMWB_SCRIPT_FILE
echo "_______________________              "         >> $OMWB_SCRIPT_FILE
echo "* PLATFORM VERSION:                  "         >> $OMWB_SCRIPT_FILE
cat /proc/cpuinfo | grep cores | tail -1           >> $OMWB_SCRIPT_FILE
echo "-                                     "        >> $OMWB_SCRIPT_FILE
echo "* PLATFORM CODEPAGE:                "          >> $OMWB_SCRIPT_FILE
free -m                                            >> $OMWB_SCRIPT_FILE
echo "-                                     "        >> $OMWB_SCRIPT_FILE
echo "-                                     "        >> $OMWB_SCRIPT_FILE
echo "-                                     "        >> $OMWB_SCRIPT_FILE
echo "SOURCE DATABASE SERVER PROPERTIES    "         >> $OMWB_SCRIPT_FILE
echo "__________________________________    "        >> $OMWB_SCRIPT_FILE
echo "* BCP VERSION:                       "         >> $OMWB_SCRIPT_FILE
bcp -v                                             >> $OMWB_SCRIPT_FILE
echo "-                                     "        >> $OMWB_SCRIPT_FILE
echo "* DATABSE SERVER COLLATION AND VERSION:"       >> $OMWB_SCRIPT_FILE
isql -U$1 -P$2 -S$4 -i$3  -i properties.sql        >> $OMWB_SCRIPT_FILE
echo "-                                   "          >> $OMWB_SCRIPT_FILE
echo "-                                   "          >> $OMWB_SCRIPT_FILE
echo "-                                   "          >> $OMWB_SCRIPT_FILE
echo "DIRECTORY LISTING for $3            "         >> $OMWB_SCRIPT_FILE
echo "__________________________________  "          >> $OMWB_SCRIPT_FILE
ls -l $3                                           >> $OMWB_SCRIPT_FILE
echo "-                                           "  >> $OMWB_SCRIPT_FILE
echo "-                                          "   >> $OMWB_SCRIPT_FILE
echo "-                                         "    >> $OMWB_SCRIPT_FILE
echo "DIRECTORY LISTING FOR MASTER             "     >> $OMWB_SCRIPT_FILE
echo "_______________________________         "      >> $OMWB_SCRIPT_FILE
ls -l master                                       >> $OMWB_SCRIPT_FILE
echo "-                                        "     >> $OMWB_SCRIPT_FILE
echo "-                                        "     >> $OMWB_SCRIPT_FILE
echo "-                                         "    >> $OMWB_SCRIPT_FILE
echo "ATTRIBUTES OF SCRIPT:                      "   >> $OMWB_SCRIPT_FILE
echo "_______________________                    "   >> $OMWB_SCRIPT_FILE
#ls -l SYB15_OFFLINE_CAPTURE.bat                   >> $OMWB_SCRIPT_FILE
echo "-                                          "   >> $OMWB_SCRIPT_FILE
echo "-                                          "   >> $OMWB_SCRIPT_FILE
echo "-                                          "   >> $OMWB_SCRIPT_FILE
echo "CONTENTS OF EXECUTED SCRIPT                "   >> $OMWB_SCRIPT_FILE
echo "____________________________________       "   >> $OMWB_SCRIPT_FILE
#cat SYB15_OFFLINE_CAPTURE.BAT                      >> $OMWB_SCRIPT_FILE
echo "-                                          "   >> $OMWB_SCRIPT_FILE
echo "-                                         "    >> $OMWB_SCRIPT_FILE
echo "-                                         "    >> $OMWB_SCRIPT_FILE
echo "CONTENTS OF BCP SCRIPT                    "    >> $OMWB_SCRIPT_FILE
echo "____________________________________      "    >> $OMWB_SCRIPT_FILE
#cat SYB15_BCP_SCRIPT.BAT                           >> $OMWB_SCRIPT_FILE
echo "-                                          "   >> $OMWB_SCRIPT_FILE
echo "-                                         "    >> $OMWB_SCRIPT_FILE
echo "-                                        "     >> $OMWB_SCRIPT_FILE
echo "** END REPORT FOR $3                        "  >> $OMWB_SCRIPT_FILE
echo "**************************************************************************"
echo "** The offline capture script has completed execution.                  "
echo "** Please review the screen output and .err files - if any-  in the output"
echo "** directories for any irregularities. You may need to execute the"
echo "** script again to resolve any irregularities.               "
echo "**                                                      "      
echo "** Finally, please archive the directory containing the sybase15.ocp file."
echo "** This contains master and $3 directories -preserve the"
echo "** directory structure in the archive- the ROW.TXT, the COLUMN.TXT, and the"
echo "** sybase15.ocp file. Return the archive file to"
echo "** your Oracle representative.                                 "
echo "**************************************************************************"
# ** REMOVE THE SCRIPT VERSION ENVIRONMENT VARIABLE
export OMWB_SCRIPT_VERSION=
# ** REMOVE THE VALUE FOR THE OMWB FILE ENVIRONMENT VARIABLE
export OMWB_SCRIPT_FILE=
# ** REMOVE THE VALUE FOR THE END OF ROW DELIMITER ENVIRONMENT VARIABLE
export OFFLINE_CAPTURE_ROW_DELIMITER=
# ** REMOVE THE VALUE FOR THE END OF COLUMN ENVIRONMENT VARIABLE
export OFFLINE_CAPTURE_COLUMN_DELIMITER=

