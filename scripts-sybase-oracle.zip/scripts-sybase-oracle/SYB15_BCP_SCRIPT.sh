#! /bin/bash
#  $1 DBA login id
#  $2 password
#  $3 database name
#  $4 database server name
#  $5 end or column delimiter
#  $6 end of row delimiter


# export the required system tables in the master database
bcp sysdatabases out master/SYB12_SYSDATABASES.dat -c  -t '\t<EOC>\t' -r '\t<EOC>\t<EOR>\n' -U$1 -P$2 -S$4

# export the required system tables in the database to be migrated

bcp $3.dbo.sysusers out $3/SYB12_SYSUSERS.dat -c -t '\t<EOC>\t' -r '\t<EOC>\t<EOR>\n' -U$1 -P$2 -S$4
bcp $3.dbo.sysobjects out $3/SYB12_SYSOBJECTS.dat -c -t '\t<EOC>\t' -r '\t<EOC>\t<EOR>\n' -U$1 -P$2 -S$4
bcp $3.dbo.systypes out $3/SYB12_SYSTYPES.dat -c -t '\t<EOC>\t' -r '\t<EOC>\t<EOR>\n' -U$1 -P$2 -S$4
bcp $3.dbo.syscolumns out $3/SYB12_SYSCOLUMNS.dat -c -t '\t<EOC>\t' -r '\t<EOC>\t<EOR>\n'  -U$1 -P$2 -S$4
bcp $3.dbo.syscomments out $3/SYB12_SYSCOMMENTS.dat -c -t '\t<EOC>\t' -r '\t<EOC>\t<EOR>\n'  -U$1 -P$2 -S$4
isql -U$1 -P$2 -D$3 -S$4 -b -i get_indexes.sql -o $3/SYB12_SYSINDEXES.dat
isql -U$1 -P$2 -D$3 -S$4 -b -w200 -i get_constraints.sql -o $3/SYB12_SYSCONSTRAINTS.dat